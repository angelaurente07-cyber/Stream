# Brand

Status: **name is PROVISIONAL.** The code uses "Estante" as a working name. None of the checks in
Step 2 have been run (no access from this environment). Nothing here is legal clearance.

## Angle (assumed)

`replica/fixes.md` does not exist: `/replica-entrepreneur` has not run (it needs to read public
reviews, which this environment cannot reach). The angle below is inferred from what was built.
Correct it if it is wrong:

> A simple, Spanish-first app for people who run their own media server: log in, find, play,
> and take a copy with you in the quality you choose.

## Step 1: the name

Rules from the original's own branding page: third parties must not use the name "Jellyfin", and the
project discourages "Jelly[word]" and "[word]fin". Its logo is a rounded triangle inside a triangle:
do not use that shape or any variation. Also avoid sounding like others in the category: Plex, Emby,
Kodi, Infuse, Swiftfin, Finamp, Streamyfin, Findroid.

20 candidates:

| style | candidates |
| --- | --- |
| descriptive | MiMediateca, Videoteca Personal |
| compound | Peliteca, Cinebox |
| invented | Lumo, Vexo, Orvia, Nubra |
| metaphor | Faro, Estante, Brasa, Rincón, Sofá, Butaca, Palco, Mirador, Noria, Baúl |
| verb | Mira, Ver |

Cut (and why):
- Peliteca, Cinebox: "peli…" names are all over pirate streaming sites in Spanish. Bad association, risky with app stores.
- MiMediateca, Videoteca Personal, Ver: generic words, not protectable.
- Faro: FARO Technologies is a well-known software and hardware company. Likely conflict.
- Sofá: an app called "Sofa" already exists in the same kind of category.
- Orvia: sounds close to Orbia (a large company). Lumo, Vexo, Nubra: very common invented shapes, many existing marks.
- Palco: a known Brazilian music platform. Butaca: many Spanish cinema apps use it.
- Brasa, Baúl, Mira: no link to the angle, or awkward in English (accent mark in handles).

**Finalists (best first):**

| # | name | type | meaning | why |
| --- | --- | --- | --- | --- |
| 1 | **Estante** | metaphor | shelf (also shelf in Portuguese) | your library on your shelf. Short, easy to say, rare in English trademark databases (not yet checked) |
| 2 | Noria | metaphor | water wheel, Ferris wheel in Spanish | things keep coming round to you. Short. Industrial company with a similar name likely exists |
| 3 | Mirador | metaphor | viewpoint | watching and looking. Longer, commonly used |
| 4 | Rincón | metaphor | cosy corner | warm, personal. Sonos was originally "Rincon Networks": a sign of crowding in tech |
| 5 | Cinta | metaphor | ribbon, tape, film | film tape. Close to "Cintas", a big US company (other classes) |

None sounds like the original or the other apps listed above. Sound, look and meaning were compared by me, not by a trademark office.

## Step 2: the checks (all TO RUN)

Run each for the five names. Write the result and the date. Do not write "available" without running it.

| check | where | Estante | Noria | Mirador | Rincón | Cinta |
| --- | --- | --- | --- | --- | --- | --- |
| US trademark (classes 9 and 42) | tmsearch.uspto.gov | to run | to run | to run | to run | to run |
| EU trademark | euipo.europa.eu eSearch, TMview | to run | to run | to run | to run | to run |
| Mexico and Spain | IMPI marcia, OEPM | to run | to run | to run | to run | to run |
| Canada | ised-isde.canada.ca | to run | to run | to run | to run | to run |
| global | WIPO Global Brand Database | to run | to run | to run | to run | to run |
| domain | `whois`, or a registrar: try name.app, name.io, getname.com | to run | to run | to run | to run | to run |
| App Store and Google Play | search the exact name | to run | to run | to run | to run | to run |
| handles | X, Instagram, TikTok, GitHub | to run | to run | to run | to run | to run |
| the web | search "name + app" and "name + media server" | to run | to run | to run | to run | to run |

These are screening checks. Before spending money, a trademark lawyer should do a proper search.

## Step 3: palette

Two families to stay away from, not one: the original's purple and blue, and the amber of the best-known
rival (the first draft of this system was dark graphite with an amber accent, which looked too much like it).
Emby's green and Netflix's red are also avoided.

New accent: **rose** (raspberry in the light theme). Neutrals stay graphite and are generic.

| role | dark | light |
| --- | --- | --- |
| accent | #ff7aa8 | #b3124f |
| on-accent | #2a0a16 | #ffffff |

All other roles unchanged. Contrast: `python3 design/contrast.py design/tokens.json` and
`tokens.light.json`: 20 pairs each, **0 failing AA**. The original's colours were added to
`brand.json` so the sweep catches them (verify the hex values, see that file).

## Step 4: logo brief

- **Idea:** a shelf with things on it: your own collection, within reach.
- **Mark type:** symbol plus wordmark. Wordmark in the system sans, lowercase `estante`.
- **Symbol:** a rounded square holding three vertical bars of different heights standing on a thin
  line (like spines on a shelf). One bar in the accent colour, the rest in text colour.
- **Must work at 16px** (the line may drop away, three bars stay) and as a 1024px app icon.
- **Deliverables:** SVG (symbol, wordmark, both), app icon 1024x1024 with no transparency (iOS),
  favicon set (16, 32, 180, 512), social image 1200x630, dark and light versions.
- **Must not resemble the original's mark:** no triangle of any kind (that includes a play triangle and a
  triangle inside a triangle, even rounded or rotated), no jellyfish or tentacle shapes, no purple-to-blue
  gradient. Also no chevron (a rival's shape) and no letter "e" with a play button inside (another's).
  Put the original's logo next to the drafts and check by eye.

No logo has been made. The app has no favicon yet.

## Step 5: voice

Three words:
- **Cercana, no cursi.** Talks like a friend who knows the topic. No diminutives, no emojis, no "¡Hola, cinéfilo!".
- **Clara, no técnica.** Says what happened and what to do. "CORS" appears only where there is no other way.
- **Tranquila, no apagada.** No exclamation marks, no panic. Errors say what to do next.

| do | don't |
| --- | --- |
| "Ese usuario o esa contraseña no coinciden." | "¡Credenciales inválidas!" |
| "Todavía no hay nada por aquí." | "No se encontraron elementos." |
| "Sigue donde lo dejaste" | "Continuar reproducción" |
| "Algo falló. Inténtalo otra vez en un momento." | "Error 500: fallo interno del servidor" |
| "Listo, guardado como Peli (2020).mkv" | "¡Descarga completada con éxito! 🎉" |

Ten most-seen strings rewritten in `src/strings.ts` (login title, wrong password, server not found,
continue watching, empty state, play button, generic error, no results, session ended, download done).
All new, none echoing the original's phrasing.

## Step 6: the sweep

```
python3 sweep.py client --config replica/brand.json
Clean. Nothing of the original's name, domain or colours found.
```

Searched: names (Jellyfin, Jellyfin Project), domain (jellyfin.org), colours (#aa5cc3, #00a4dc).
Fixed first: one mention in the README. Checked by eye in code: page title is now "Estante", the request
header name is "Estante". Not done: favicon, OG image, app icon, email templates (none exist yet).

## Open decisions

1. Confirm or correct the angle.
2. Run the checks and choose the name (or send me other candidates). Renaming is one line (`APP_NAME` in `src/strings.ts`) plus the tests that read the header.
3. Decide if marketing copy may say "works with Jellyfin servers". That is a legal question: the original asks third parties not to use its name directly. Ask a lawyer before using it anywhere public, including the store listing.
